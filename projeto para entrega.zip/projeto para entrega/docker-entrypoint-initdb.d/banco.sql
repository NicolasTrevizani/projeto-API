-- Cria o banco de dados se ele não existir
CREATE DATABASE IF NOT EXISTS minha_api_db;

-- Seleciona o banco de dados para uso
USE minha_api_db;

-- Cria a tabela jogos se ela não existir
CREATE TABLE IF NOT EXISTS jogos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    plataforma VARCHAR(255) NOT NULL,
    genero VARCHAR(255),
    preco DECIMAL(10, 2) NOT NULL,
    desenvolvedora VARCHAR(255),
    publicadora VARCHAR(255),
    data_lancamento DATE,
    descricao TEXT,
    estoque INT UNSIGNED DEFAULT 0,
    capa_url VARCHAR(255),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insere alguns dados de exemplo na tabela jogos
INSERT INTO jogos (titulo, plataforma, genero, preco, desenvolvedora, publicadora, data_lancamento, descricao, estoque, capa_url) VALUES
('The Last of Us Part I', 'PlayStation 5', 'Ação, Aventura', 249.90, 'Naughty Dog', 'Sony Interactive Entertainment', '2022-09-02', 'Vivencie a emocionante história e os personagens inesquecíveis de The Last of Us, vencedor de mais de 200 prêmios de Jogo do Ano.', 10, 'https://example.com/capa_tlou1.jpg'),
('Red Dead Redemption 2', 'PC', 'Ação, Aventura, Mundo Aberto', 199.99, 'Rockstar Games', 'Rockstar Games', '2019-11-05', 'Uma história épica sobre honra e lealdade no alvorecer da era moderna.', 5, 'https://example.com/capa_rdr2.jpg'),
('The Legend of Zelda: Tears of the Kingdom', 'Nintendo Switch', 'Ação, Aventura, Mundo Aberto', 299.99, 'Nintendo', 'Nintendo', '2023-05-12', 'Uma aventura épica pelos céus e pela vasta terra de Hyrule.', 8, 'https://example.com/capa_zelda.jpg'),
('Cyberpunk 2077', 'PC', 'RPG, Mundo Aberto', 179.90, 'CD Projekt Red', 'CD Projekt Red', '2020-12-10', 'Um RPG de ação e aventura em mundo aberto ambientado na megalópole de Night City.', 12, 'https://example.com/capa_cyberpunk.jpg'),
('Stardew Valley', 'PC', 'Simulação, RPG', 69.99, 'ConcernedApe', 'ConcernedApe', '2016-02-26', 'Você herdou a antiga fazenda de seu avô em Stardew Valley. Equipado com ferramentas de segunda mão e algumas moedas, você decide começar sua nova vida.', 20, 'https://example.com/capa_stardew.jpg');

-- Consulta para verificar os dados inseridos (opcional)
SELECT * FROM jogos;