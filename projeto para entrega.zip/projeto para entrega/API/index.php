<?php
// Configurações do Banco de Dados (obtidas das variáveis de ambiente)
$db_host = getenv('DB_HOST'); // Deve ser 'db'
$db_name = getenv('MYSQL_DATABASE'); // Deve ser 'minha_api_db'
$db_user = getenv('MYSQL_USER'); // Deve ser 'usuario_api'
$db_pass = getenv('MYSQL_PASSWORD'); // Deve ser 'senha_api_segura'

header('Content-Type: application/json; charset=utf-8');
$response = ['status' => 'error', 'message' => 'Erro ao buscar os jogos.', 'data' => []];

// Tenta conectar ao banco de dados MySQL usando MySQLi
$conn = @new mysqli('db:3306', $db_user, $db_pass, $db_name);

// Verifica a conexão
if ($conn && !$conn->connect_error) {
    // Modifica a consulta SQL para selecionar os jogos
    $sql = "SELECT id, titulo, plataforma, genero, preco, capa_url, estoque FROM jogos WHERE estoque > 0";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $response['status'] = 'success';
            $response['message'] = 'Jogos encontrados com sucesso!';
            while ($row = $result->fetch_assoc()) {
                $response['data'][] = $row;
            }
        } else {
            $response['status'] = 'success';
            $response['message'] = 'Nenhum jogo disponível no momento.';
        }
        $result->free();
    } else {
        $response['message'] = 'Erro na consulta: ' . $conn->error;
    }

    // Fecha a conexão
    $conn->close();
} else {
    $response['message'] = 'Não foi possível conectar ao banco de dados: ' . ($conn ? $conn->connect_error : mysqli_connect_error());
}

// Exibe a resposta como JSON
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// phpinfo(); // Descomente para depuração
?>